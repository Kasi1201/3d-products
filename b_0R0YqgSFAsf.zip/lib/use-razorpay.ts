'use client'

import { useCallback, useEffect, useState } from 'react'

interface RazorpayOptions {
  amount: number // Amount in paise (INR)
  currency?: string
  name?: string
  description?: string
  prefill?: {
    name?: string
    email?: string
    contact?: string
  }
  theme?: {
    color?: string
  }
  onSuccess?: (response: RazorpaySuccessResponse) => void
  onError?: (error: Error) => void
}

interface RazorpaySuccessResponse {
  razorpay_payment_id: string
  razorpay_order_id?: string
  razorpay_signature?: string
}

interface RazorpayInstance {
  open: () => void
  close: () => void
  on: (event: string, callback: (response: RazorpaySuccessResponse) => void) => void
}

declare global {
  interface Window {
    Razorpay: new (options: Record<string, unknown>) => RazorpayInstance
  }
}

// Test API Key - Replace with your actual key for production
const RAZORPAY_KEY_ID = process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || 'rzp_test_placeholder'

export function useRazorpay() {
  const [isLoaded, setIsLoaded] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)

  useEffect(() => {
    // Check if script is already loaded
    if (window.Razorpay) {
      setIsLoaded(true)
      return
    }

    // Load Razorpay script
    const script = document.createElement('script')
    script.src = 'https://checkout.razorpay.com/v1/checkout.js'
    script.async = true
    script.onload = () => setIsLoaded(true)
    script.onerror = () => {
      console.error('Failed to load Razorpay SDK')
    }
    document.body.appendChild(script)

    return () => {
      // Cleanup if needed
    }
  }, [])

  const initiatePayment = useCallback(
    (options: RazorpayOptions) => {
      if (!isLoaded || !window.Razorpay) {
        options.onError?.(new Error('Razorpay SDK not loaded'))
        return
      }

      setIsProcessing(true)

      const razorpayOptions = {
        key: RAZORPAY_KEY_ID,
        amount: options.amount,
        currency: options.currency || 'INR',
        name: options.name || 'DPSLabs',
        description: options.description || 'Premium 3D Printed Products',
        image: '/icon.svg',
        prefill: {
          name: options.prefill?.name || '',
          email: options.prefill?.email || '',
          contact: options.prefill?.contact || '',
        },
        theme: {
          color: options.theme?.color || '#3b82f6',
        },
        handler: function (response: RazorpaySuccessResponse) {
          setIsProcessing(false)
          options.onSuccess?.(response)
        },
        modal: {
          ondismiss: function () {
            setIsProcessing(false)
          },
        },
      }

      try {
        const razorpay = new window.Razorpay(razorpayOptions)
        razorpay.open()
      } catch (error) {
        setIsProcessing(false)
        options.onError?.(error instanceof Error ? error : new Error('Payment failed'))
      }
    },
    [isLoaded]
  )

  return {
    isLoaded,
    isProcessing,
    initiatePayment,
  }
}
