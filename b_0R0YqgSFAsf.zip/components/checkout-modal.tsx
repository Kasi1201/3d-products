'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { CheckCircle, CreditCard, Loader2, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useCart } from '@/lib/cart-context'
import { useRazorpay } from '@/lib/use-razorpay'
import { formatPrice } from '@/lib/products'

interface CheckoutModalProps {
  isOpen: boolean
  onClose: () => void
}

export default function CheckoutModal({ isOpen, onClose }: CheckoutModalProps) {
  const { items, totalPrice, clearCart, setIsCartOpen } = useCart()
  const { isLoaded, isProcessing, initiatePayment } = useRazorpay()

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
  })
  const [paymentSuccess, setPaymentSuccess] = useState(false)
  const [paymentId, setPaymentId] = useState('')

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }))
  }

  const handlePayment = () => {
    if (!formData.name || !formData.email || !formData.phone) {
      alert('Please fill in all required fields')
      return
    }

    initiatePayment({
      amount: totalPrice * 100, // Convert to paise
      description: `Order of ${items.length} item(s) from DPSLabs`,
      prefill: {
        name: formData.name,
        email: formData.email,
        contact: formData.phone,
      },
      onSuccess: (response) => {
        setPaymentId(response.razorpay_payment_id)
        setPaymentSuccess(true)
        clearCart()
        setIsCartOpen(false)
      },
      onError: (error) => {
        alert(`Payment failed: ${error.message}`)
      },
    })
  }

  const handleClose = () => {
    if (paymentSuccess) {
      setPaymentSuccess(false)
      setPaymentId('')
      setFormData({ name: '', email: '', phone: '', address: '' })
    }
    onClose()
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50"
            onClick={handleClose}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-md bg-card border border-border rounded-2xl z-50 overflow-hidden"
          >
            {paymentSuccess ? (
              /* Success State */
              <div className="p-8 text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', damping: 15, stiffness: 200 }}
                  className="w-20 h-20 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-6"
                >
                  <CheckCircle size={40} className="text-green-500" />
                </motion.div>
                <h2 className="text-2xl font-bold text-foreground mb-2">
                  Payment Successful!
                </h2>
                <p className="text-muted-foreground mb-4">
                  Thank you for your order. We&apos;ll contact you shortly.
                </p>
                <p className="text-sm text-muted-foreground mb-6">
                  Payment ID: <span className="font-mono text-foreground">{paymentId}</span>
                </p>
                <Button onClick={handleClose} className="w-full rounded-xl h-12">
                  Continue Shopping
                </Button>
              </div>
            ) : (
              /* Checkout Form */
              <>
                {/* Header */}
                <div className="flex items-center justify-between p-6 border-b border-border">
                  <div className="flex items-center gap-3">
                    <CreditCard size={24} className="text-accent" />
                    <h2 className="text-xl font-semibold text-foreground">Checkout</h2>
                  </div>
                  <button
                    onClick={handleClose}
                    className="p-2 rounded-full hover:bg-secondary transition-colors"
                    aria-label="Close"
                  >
                    <X size={20} className="text-muted-foreground" />
                  </button>
                </div>

                {/* Form */}
                <div className="p-6 space-y-4">
                  <div>
                    <label className="text-sm text-muted-foreground mb-1.5 block">
                      Full Name *
                    </label>
                    <Input
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="John Doe"
                      className="rounded-xl h-12 bg-secondary/30"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-1.5 block">
                      Email *
                    </label>
                    <Input
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="john@example.com"
                      className="rounded-xl h-12 bg-secondary/30"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-1.5 block">
                      Phone *
                    </label>
                    <Input
                      name="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="+91 9876543210"
                      className="rounded-xl h-12 bg-secondary/30"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-1.5 block">
                      Delivery Address
                    </label>
                    <Input
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      placeholder="Your delivery address"
                      className="rounded-xl h-12 bg-secondary/30"
                    />
                  </div>
                </div>

                {/* Summary */}
                <div className="px-6 pb-6">
                  <div className="p-4 rounded-xl bg-secondary/30 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Items</span>
                      <span className="text-foreground">{items.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-semibold text-foreground">Total</span>
                      <span className="text-xl font-bold text-accent">
                        {formatPrice(totalPrice)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Action */}
                <div className="p-6 pt-0">
                  <Button
                    size="lg"
                    className="w-full bg-foreground text-background hover:bg-foreground/90 rounded-xl h-14 font-medium"
                    onClick={handlePayment}
                    disabled={!isLoaded || isProcessing}
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>Pay {formatPrice(totalPrice)}</>
                    )}
                  </Button>
                  <p className="text-xs text-center text-muted-foreground mt-4">
                    Secure payment powered by Razorpay
                  </p>
                </div>
              </>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
