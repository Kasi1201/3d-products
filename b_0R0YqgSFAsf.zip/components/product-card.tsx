'use client'

import { motion } from 'framer-motion'
import { MessageCircle, Plus, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useCart } from '@/lib/cart-context'
import { formatPrice, type Product } from '@/lib/products'
import Product3D from './product-3d'

interface ProductCardProps {
  product: Product
  delay?: number
}

export default function ProductCard({ product, delay = 0 }: ProductCardProps) {
  const { addToCart } = useCart()

  const whatsappMessage = encodeURIComponent(
    `Hi! I'm interested in ordering the ${product.name} (${formatPrice(product.price)}). Can you provide more details?`
  )

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.6, delay }}
      className="group"
    >
      <div className="relative rounded-3xl bg-card/60 backdrop-blur-sm border border-border/50 p-4 sm:p-6 overflow-hidden transition-all duration-500 hover:border-accent/30 hover:bg-card/80">
        {/* Trending Badge */}
        {product.trending && (
          <div className="absolute top-4 left-4 z-20">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500 text-background text-xs font-semibold">
              <Sparkles size={10} />
              Trending
            </span>
          </div>
        )}

        {/* Glow Effect */}
        <div
          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
          style={{
            background: `radial-gradient(circle at 50% 0%, ${product.color}10 0%, transparent 50%)`,
          }}
        />

        {/* 3D Preview */}
        <div className="relative z-10 rounded-2xl bg-secondary/30 overflow-hidden mb-4 sm:mb-6">
          <Product3D type={product.type} color={product.color} />
        </div>

        {/* Content */}
        <div className="relative z-10">
          {/* Category */}
          <span className="text-xs text-accent font-medium uppercase tracking-wider">
            {product.category}
          </span>

          <div className="flex items-start justify-between mt-1 mb-2 sm:mb-3">
            <h3 className="text-lg sm:text-xl font-semibold text-foreground pr-2">
              {product.name}
            </h3>
            <span className="text-lg sm:text-xl font-bold text-accent whitespace-nowrap">
              {formatPrice(product.price)}
            </span>
          </div>

          <p className="text-sm text-muted-foreground mb-4 sm:mb-6 line-clamp-2">
            {product.description}
          </p>

          {/* Actions */}
          <div className="flex gap-2">
            <Button
              className="flex-1 bg-foreground text-background hover:bg-foreground/90 rounded-xl h-11 sm:h-12 font-medium"
              onClick={() => addToCart(product)}
            >
              <Plus className="mr-1 h-4 w-4" />
              Add to Cart
            </Button>
            <Button
              asChild
              variant="outline"
              className="rounded-xl h-11 sm:h-12 px-3 border-border/50 hover:bg-card/50"
            >
              <a
                href={`https://wa.me/919390673193?text=${whatsappMessage}`}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Order via WhatsApp"
              >
                <MessageCircle className="h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>

        {/* Decorative Corner */}
        <div className="absolute top-0 right-0 w-24 sm:w-32 h-24 sm:h-32 bg-gradient-to-bl from-accent/5 to-transparent rounded-bl-full" />
      </div>
    </motion.div>
  )
}
