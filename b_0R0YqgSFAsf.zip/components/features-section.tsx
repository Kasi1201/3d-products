'use client'

import { motion } from 'framer-motion'
import { Zap, Shield, Cpu, Headphones, RefreshCw, Clock } from 'lucide-react'

const features = [
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Powered by next-generation processors for instant responsiveness.',
  },
  {
    icon: Shield,
    title: 'Secure by Design',
    description: 'Military-grade encryption keeps your data safe and private.',
  },
  {
    icon: Cpu,
    title: 'AI Powered',
    description: 'Intelligent algorithms that learn and adapt to your needs.',
  },
  {
    icon: Headphones,
    title: '24/7 Support',
    description: 'Expert assistance whenever you need it, around the clock.',
  },
  {
    icon: RefreshCw,
    title: 'Free Updates',
    description: 'Lifetime software updates to keep your device cutting-edge.',
  },
  {
    icon: Clock,
    title: '2 Year Warranty',
    description: 'Extended coverage for complete peace of mind.',
  },
]

export default function FeaturesSection() {
  return (
    <section id="features" className="relative py-20 sm:py-32 px-4 sm:px-6 bg-card/30">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 sm:mb-16"
        >
          <span className="text-accent text-sm font-medium tracking-wider uppercase">
            Why Choose Us
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mt-3 sm:mt-4 mb-4 sm:mb-6 text-balance">
            Built for Excellence
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg max-w-2xl mx-auto px-4">
            Every product is crafted with meticulous attention to detail and premium
            materials for an unparalleled experience.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group p-6 sm:p-8 rounded-2xl bg-card/50 border border-border/50 hover:border-accent/30 transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-4 sm:mb-5 group-hover:bg-accent/20 transition-colors">
                <feature.icon className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold text-foreground mb-2 sm:mb-3">
                {feature.title}
              </h3>
              <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
