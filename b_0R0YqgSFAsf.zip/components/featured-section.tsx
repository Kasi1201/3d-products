'use client'

import { motion } from 'framer-motion'
import { ShoppingCart, Sparkles, Star, TrendingUp } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { featuredProduct, formatPrice } from '@/lib/products'
import { useCart } from '@/lib/cart-context'
import Product3D from './product-3d'

export default function FeaturedSection() {
  const { addToCart } = useCart()

  const whatsappMessage = encodeURIComponent(
    `Hi! I'm interested in ordering the ${featuredProduct.name} (${formatPrice(featuredProduct.price)}). Can you provide more details?`
  )

  return (
    <section className="relative py-20 sm:py-32 px-4 sm:px-6 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-amber-500/10 rounded-full blur-3xl" />
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Top Banner */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex justify-center mb-8"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-sm font-medium">
            <TrendingUp size={16} />
            <span>Trending Now</span>
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
          </div>
        </motion.div>

        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <span className="text-amber-400 text-sm font-medium tracking-wider uppercase">
            Featured Collection
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mt-3 mb-4 text-balance">
            Exclusive Release
          </h2>
        </motion.div>

        {/* Featured Product Card */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative"
        >
          <div className="relative rounded-3xl bg-gradient-to-br from-amber-500/10 via-card/80 to-card/60 backdrop-blur-xl border border-amber-500/20 overflow-hidden">
            {/* Glow Effect */}
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-amber-500/20 rounded-full blur-3xl" />
            <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-amber-600/10 rounded-full blur-3xl" />

            <div className="relative grid lg:grid-cols-2 gap-8 p-6 sm:p-8 lg:p-12">
              {/* 3D Preview */}
              <div className="relative rounded-2xl bg-gradient-to-br from-amber-500/5 to-transparent overflow-hidden order-2 lg:order-1">
                <div className="absolute top-4 left-4 z-10">
                  <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-amber-500 text-background text-xs font-semibold">
                    <Sparkles size={12} />
                    Limited Edition
                  </span>
                </div>
                <Product3D type="cube" color="#f59e0b" />
              </div>

              {/* Content */}
              <div className="flex flex-col justify-center order-1 lg:order-2">
                {/* Rating */}
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={18}
                      className="fill-amber-400 text-amber-400"
                    />
                  ))}
                  <span className="text-sm text-muted-foreground ml-2">
                    (128 reviews)
                  </span>
                </div>

                {/* Title */}
                <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground mb-2">
                  {featuredProduct.name}
                </h3>
                <p className="text-amber-400 text-sm font-medium mb-4">
                  Inspired by &quot;They Call Him OG&quot;
                </p>

                {/* Description */}
                <p className="text-muted-foreground text-base sm:text-lg mb-6 leading-relaxed">
                  {featuredProduct.description}
                </p>

                {/* Features */}
                <div className="grid grid-cols-2 gap-4 mb-8">
                  {[
                    'Premium PLA Material',
                    'Hand-Painted Details',
                    'Collector Quality',
                    'Gift Box Included',
                  ].map((feature, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                      <span className="text-sm text-muted-foreground">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* Price */}
                <div className="mb-8">
                  <span className="text-4xl sm:text-5xl font-bold text-foreground">
                    {formatPrice(featuredProduct.price)}
                  </span>
                  <span className="text-muted-foreground ml-2 line-through">
                    {formatPrice(3999)}
                  </span>
                  <span className="ml-3 text-sm font-medium text-green-400">
                    25% OFF
                  </span>
                </div>

                {/* Actions */}
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button
                    size="lg"
                    className="bg-amber-500 text-background hover:bg-amber-600 rounded-xl h-14 px-8 font-medium flex-1"
                    onClick={() => addToCart(featuredProduct)}
                  >
                    <ShoppingCart className="mr-2 h-5 w-5" />
                    Add to Cart
                  </Button>
                  <Button
                    asChild
                    variant="outline"
                    size="lg"
                    className="rounded-xl h-14 px-8 font-medium border-amber-500/30 hover:bg-amber-500/10 hover:border-amber-500/50 flex-1"
                  >
                    <a
                      href={`https://wa.me/919390673193?text=${whatsappMessage}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Order on WhatsApp
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
