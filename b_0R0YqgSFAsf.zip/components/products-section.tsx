'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { products, categories, type Category } from '@/lib/products'
import ProductCard from './product-card'

export default function ProductsSection() {
  const [activeCategory, setActiveCategory] = useState<Category>('All')
  const [showAll, setShowAll] = useState(false)

  const filteredProducts =
    activeCategory === 'All'
      ? products
      : products.filter((product) => product.category === activeCategory)

  const displayedProducts = showAll ? filteredProducts : filteredProducts.slice(0, 9)

  return (
    <section id="products" className="relative py-20 sm:py-32 px-4 sm:px-6">
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-0 w-64 sm:w-96 h-64 sm:h-96 bg-accent/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-0 w-64 sm:w-96 h-64 sm:h-96 bg-blue-500/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 sm:mb-16"
        >
          <span className="text-accent text-sm font-medium tracking-wider uppercase">
            Our Collection
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mt-3 sm:mt-4 mb-4 sm:mb-6 text-balance">
            Premium 3D Printed Products
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg max-w-2xl mx-auto px-4">
            Discover our carefully curated selection of handcrafted 3D printed products designed
            to elevate your space and lifestyle.
          </p>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-10 sm:mb-12"
        >
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => {
                setActiveCategory(category)
                setShowAll(false)
              }}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                activeCategory === category
                  ? 'bg-foreground text-background'
                  : 'bg-card/60 text-muted-foreground hover:text-foreground hover:bg-card/80 border border-border/50'
              }`}
            >
              {category}
            </button>
          ))}
        </motion.div>

        {/* Products Count */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center text-sm text-muted-foreground mb-8"
        >
          Showing {displayedProducts.length} of {filteredProducts.length} products
        </motion.p>

        {/* Product Grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeCategory}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8"
          >
            {displayedProducts.map((product, index) => (
              <ProductCard
                key={product.id}
                product={product}
                delay={index * 0.05}
              />
            ))}
          </motion.div>
        </AnimatePresence>

        {/* Show More Button */}
        {filteredProducts.length > 9 && !showAll && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mt-12"
          >
            <button
              onClick={() => setShowAll(true)}
              className="px-8 py-3 rounded-full bg-card/60 border border-border/50 text-foreground font-medium hover:bg-card/80 hover:border-accent/30 transition-all duration-300"
            >
              View All {filteredProducts.length} Products
            </button>
          </motion.div>
        )}

        {showAll && filteredProducts.length > 9 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mt-12"
          >
            <button
              onClick={() => setShowAll(false)}
              className="px-8 py-3 rounded-full bg-card/60 border border-border/50 text-foreground font-medium hover:bg-card/80 hover:border-accent/30 transition-all duration-300"
            >
              Show Less
            </button>
          </motion.div>
        )}
      </div>
    </section>
  )
}
