'use client'

import { useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Float, RoundedBox, Environment, ContactShadows } from '@react-three/drei'
import * as THREE from 'three'

type ShapeType = 'cube' | 'sphere' | 'torus' | 'octahedron' | 'icosahedron' | 'dodecahedron'

interface ProductMeshProps {
  type: ShapeType
  color: string
}

function ProductMesh({ type, color }: ProductMeshProps) {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = state.clock.elapsedTime * 0.5
    }
  })

  return (
    <Float speed={1.5} rotationIntensity={0.3} floatIntensity={0.5}>
      {type === 'cube' && (
        <RoundedBox ref={meshRef} args={[1.2, 1.2, 1.2]} radius={0.1} smoothness={4}>
          <meshStandardMaterial
            color={color}
            metalness={0.9}
            roughness={0.1}
            envMapIntensity={1}
          />
        </RoundedBox>
      )}
      {type === 'sphere' && (
        <mesh ref={meshRef}>
          <sphereGeometry args={[0.8, 64, 64]} />
          <meshStandardMaterial
            color={color}
            metalness={0.95}
            roughness={0.05}
            envMapIntensity={1.5}
          />
        </mesh>
      )}
      {type === 'torus' && (
        <mesh ref={meshRef}>
          <torusKnotGeometry args={[0.5, 0.2, 128, 16]} />
          <meshStandardMaterial
            color={color}
            metalness={0.9}
            roughness={0.1}
            envMapIntensity={1}
          />
        </mesh>
      )}
      {type === 'octahedron' && (
        <mesh ref={meshRef}>
          <octahedronGeometry args={[0.9, 0]} />
          <meshStandardMaterial
            color={color}
            metalness={0.85}
            roughness={0.15}
            envMapIntensity={1}
          />
        </mesh>
      )}
      {type === 'icosahedron' && (
        <mesh ref={meshRef}>
          <icosahedronGeometry args={[0.85, 0]} />
          <meshStandardMaterial
            color={color}
            metalness={0.9}
            roughness={0.1}
            envMapIntensity={1.2}
          />
        </mesh>
      )}
      {type === 'dodecahedron' && (
        <mesh ref={meshRef}>
          <dodecahedronGeometry args={[0.85, 0]} />
          <meshStandardMaterial
            color={color}
            metalness={0.88}
            roughness={0.12}
            envMapIntensity={1.1}
          />
        </mesh>
      )}
    </Float>
  )
}

interface Product3DProps {
  type: ShapeType
  color: string
}

export default function Product3D({ type, color }: Product3DProps) {
  return (
    <div className="w-full h-48 sm:h-56">
      <Canvas
        camera={{ position: [0, 0, 4], fov: 35 }}
        gl={{ antialias: true, alpha: true }}
        dpr={[1, 2]}
      >
        <Environment preset="city" />
        <ambientLight intensity={0.3} />
        <directionalLight position={[5, 5, 5]} intensity={1} />
        <spotLight
          position={[-5, 5, 5]}
          angle={0.3}
          penumbra={1}
          intensity={0.5}
          color={color}
        />
        
        <ProductMesh type={type} color={color} />
        
        <ContactShadows
          position={[0, -1.2, 0]}
          opacity={0.4}
          scale={5}
          blur={2}
          far={4}
        />
      </Canvas>
    </div>
  )
}
