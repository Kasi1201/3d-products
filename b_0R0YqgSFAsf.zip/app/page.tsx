import Navbar from '@/components/navbar'
import HeroSection from '@/components/hero-section'
import ProductsSection from '@/components/products-section'
import FeaturesSection from '@/components/features-section'
import Footer from '@/components/footer'
import WhatsAppButton from '@/components/whatsapp-button'

export default function Home() {
  return (
    <main className="min-h-screen bg-background overflow-x-hidden">
      <Navbar />
      <HeroSection />
      <ProductsSection />
      <FeaturesSection />
      <Footer />
      <WhatsAppButton />
    </main>
  )
}
